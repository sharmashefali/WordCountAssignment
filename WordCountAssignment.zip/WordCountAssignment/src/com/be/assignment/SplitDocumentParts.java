package com.be.assignment;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class SplitDocumentParts {

	static Long words = 0L;
	static List<Map.Entry<String, Long>>[] top5 = new ArrayList[10];
	static Map<String, Long> top5Words = new HashMap<>();

	public static void main(String args[]) {

		BufferedReader reader = null;
		ArrayList<Thread> threads = new ArrayList<Thread>();
		try {
			URL url = new URL("http://www.gutenberg.org/files/2600/2600-0.txt");
			reader = new BufferedReader(new InputStreamReader(url.openStream()));
		} catch (FileNotFoundException | MalformedURLException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < 10; i++) {
			Runnable task = new ProcessParts(reader, i);
			Thread worker = new Thread(task);
			worker.setName(String.valueOf(i));
			worker.start();
			threads.add(worker);
		}

		int running = 0;
		int runner1 = 0;
		do {
			running = 0;
			for (Thread thread : threads) {
				if (thread.isAlive()) {
					runner1 = running++;
				}
			}
		} while (running > 0);
		
		System.out.println("Total word count: " + words);
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 5; j++) {
				String key = top5[i].get(j).getKey();
				Long value = top5[i].get(j).getValue();

				if (top5Words.keySet().contains(key)) {
					top5Words.put(key, top5Words.get(key) + value);
				} else {
					top5Words.put(key, value);
				}
			}
		}
		
		System.out.println("____Top 5 Most used words____");
		for (Entry<String, Long> entry : top5Words.entrySet())
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());

	}
}
