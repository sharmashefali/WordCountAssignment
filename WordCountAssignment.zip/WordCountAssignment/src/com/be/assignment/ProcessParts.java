package com.be.assignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProcessParts implements Runnable {

	BufferedReader bReader = null;
	int index;

	ProcessParts(BufferedReader reader, int index) {
		this.bReader = reader;
		this.index = index;
	}

	public synchronized void run() {
		int countWord = 0;
		String line;
		List<String> list = new ArrayList<String>();
		try {
			while ((line = bReader.readLine()) != null) {

				if (!(line.equals(""))) {
					line = line.trim();
					String[] wordList = line.split("\\s+");
					countWord += wordList.length;
					for (String s : wordList) {
						list.add(s);

					}
				}
			}

			Map<String, Long> map = list.stream().collect(Collectors.groupingBy(w -> w, Collectors.counting()));

			List<Map.Entry<String, Long>> result = map.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).limit(5)
					.collect(Collectors.toList());

			SplitDocumentParts.words += (long) countWord;
			SplitDocumentParts.top5[index] = result;
//            System.out.println("Total Words:"+countWord);
//            result.forEach(value->System.out.println(value));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
